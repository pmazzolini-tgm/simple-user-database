import server.main
import pytest

@pytest.fixture
def client():
    app = server.main.app.test_client()
    return app

def test_ping(client):
  res = client.post('/?name=bob&email=bob@alice.com&image=www.google.com')
  assert res.json == "success"
  res = client.get('/')
  assert res.json == [{
      "name": "bob",
      "email": "bob@alice.com",
      "image": "www.google.com"
  }]

