context('test', () => {
  it('test', () => {
    cy.visit('http://localhost:8080/')
    cy.get('#inputName').type('username')
    cy.get('#inputEmail').type('email')
    cy.get('#inputImage').type('image')
    cy.get('#inputButton').click()

    cy.get('')
  })
})
