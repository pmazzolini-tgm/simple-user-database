<template>
  <div class="hello">
    <div>
      <input id="inputEmail" type="email" v-model="input.email" placeholder="email">
      <input id="inputName" type="text" v-model="input.name" placeholder="username">
      <input id="inputImage" type="text" v-model="input.image" placeholder="pic">
      <input id="inputButton" type="button" v-on:click="addStudent()" value="asdasdasd">
    </div>
    <div style="border-bottom: solid" v-for="(student, index) in students">
      name: {{student.name}}<br>
      email: {{student.email}}<br>
      pic: {{student.image}}
    </div>
  </div>
</template>

<script>
  import axios from 'axios'

  export default {
    name: 'HelloWorld',
    data() {
      return {
        students: [],
        input:{
          name: "",
          email: "",
          image: ""
        }
      }
    },
    methods: {
      getStudent: function() {
        axios.get('http://localhost:5000/').then((res)=>{
          this.students = res.data
        })
      },
      addStudent: function(){
        axios.post(`http://localhost:5000/?name=${this.input.name}&email=${this.input.email}&image=${this.input.image}`).then((res)=>{
          console.log(res)
          this.getStudent()
        })
      }
    },
    created() {
      this.getStudent()
    }
  }
</script>
