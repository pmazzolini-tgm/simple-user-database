from flask import Flask, jsonify
from flask_restful import Resource, Api, reqparse
from flask_cors import CORS

import json

app = Flask(__name__)
api = Api(app)
CORS(app)

db = [{
      "name": "bob",
      "email": "bob@alice.com",
      "image": "www.google.com"
  },{
      "name": "alice",
      "email": "alice@bobo.com",
      "image": "www.google.com"
  }]
class HelloWorld(Resource):
  def post(self):
    parser = reqparse.RequestParser()
    parser.add_argument('name')
    parser.add_argument('email')
    parser.add_argument('image')

    name = parser.parse_args().name
    email = parser.parse_args().email
    image = parser.parse_args().image

    db.append({
      "name": name,
      "email": email,
      "image": image
    })
    return "success"

  def get(self):
    return db

api.add_resource(HelloWorld, '/')

if __name__ == '__main__':
    app.run(debug=True)
